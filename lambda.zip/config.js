exports.nerfGuns = ['5c:cf:7f:01:32:5f', '5c:cf:7f:01:32:f1']
